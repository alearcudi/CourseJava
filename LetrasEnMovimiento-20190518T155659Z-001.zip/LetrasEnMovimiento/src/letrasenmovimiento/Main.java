package letrasenmovimiento;


public class Main {


    public static void main(String[] args) {
        
        Letra l = new Letra('A');
        System.out.println(l);
        
        Cartel car = new Cartel ("hola");
        System.out.println(car);
        
        
//        l.letraH();
//        l.letraO(); 
//        l.letraL(); 
//        l.letraA();
//        
    }
    
}
