package letrasenmovimiento;

public class Cartel {

    private Letra[] cartel;
    private static final String SEPARADOR = " ";

    public Cartel(String texto) {
        cartel = new Letra[texto.length()];

        for (int i = 0; i < cartel.length; i++) {
            char c = texto.charAt(i);
            cartel[i] = new Letra(Character.toUpperCase(c));
        }
    }

    @Override
    public String toString() {
        String s = "";
        String sale = "";

        for (int fila = 0; fila < Letra.FILAS; fila++) {
            s = "";
            for (int i = 0; i < cartel.length; i++) {
                s = s + cartel[i].strFila(fila) + SEPARADOR;
            }
            sale += s + "\n";
        }
        return sale;
    }

    public void mostrar() {
        String s = " ";

        for (int fila = 0; fila < Letra.FILAS; fila++) {
            s = "";
            for (int i = 0; i < cartel.length; i++) {
                s = s + cartel[i].strFila(fila) + SEPARADOR;

            }
            System.out.println(s);
        }

    }

}
