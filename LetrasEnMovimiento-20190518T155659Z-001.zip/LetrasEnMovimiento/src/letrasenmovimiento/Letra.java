package letrasenmovimiento;

public class Letra {

    private static final char BLANCO = ' ';
    private static final char PUNTO = '*';
    public static final int FILAS = 9;
    public static final int COLUMNAS = (int) (FILAS * 0.7);
    private char[][] dibujo;
    private char letra;

    public Letra(char letra) {
        this.letra = Character.toUpperCase(letra);
        dibujo = new char[FILAS][COLUMNAS];
        switch (letra) {
            case 'A':
                dibujarA();
                break;
            case 'B':
                dibujarB();
                break;
            case 'C':
                dibujarC();
                break;
            case 'D':
                dibujarD();
                break;
            case 'E':
                dibujarE();
                break;
            case 'F':
                dibujarF();
                break;
            case 'G':
                dibujarG();
                break;
            case 'H':
                dibujarH();
                break;
            case 'I':
                dibujarI();
                break;
            case 'J':
                dibujarJ();
                break;
            case 'K':
                dibujarK();
                break;
            case 'L':
                dibujarL();
                break;
            case 'M':
                dibujarM();
                break;
            case 'N':
                dibujarN();
                break;
            case 'O':
                dibujarO();
                break;
            case 'P':
                dibujarP();
                break;
            case 'Q':
                dibujarQ();
                break;
            case 'R':
                dibujarR();
                break;
            case 'S':
                dibujarS();
                break;
            case 'T':
                dibujarT();
                break;
            case 'U':
                dibujarU();
                break;
            case 'V':
                dibujarV();
                break;
            case 'W':
                dibujarW();
                break;
            case 'X':
                dibujarX();
                break;
            case 'Y':
                dibujarY();
                break;
            case 'Z':
                dibujarZ();
                break;
        }
    }

    private void setElem(int f, int c, char caracter) {
        dibujo[f][c] = caracter;
    }

    private int ultFila() {
        return getFilas() - 1;
    }

    private int ultColumna() {
        return getColumnas() - 1;
    }

    public String toString() {
        String s = "";
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                s += getElem(f, c);
            }
            s += '\n';
        }
        return s;
    }

    public char getElem(int f, int c) {
        return dibujo[f][c];
    }

    public int getFilas() {
        return FILAS;
    }

    public int getColumnas() {
        return COLUMNAS;
    }

//    public void letraH() {
//        for (int f = 0; f < getFilas(); f++) {
//            for (int c = 0; c < getColumnas(); c++) {
//                if (f == getFilas() / 2 | c == 0 | c == getColumnas() - 1) {
//                    System.out.print(PUNTO);
//                } else {
//                    System.out.print(BLANCO);
//                }
//            }
//            System.out.println("");
//        }
//
//    }
//        public void letraO() {
//        for (int f = 0; f < getFilas(); f++) {
//            for (int c = 0; c < getColumnas(); c++) {
//                if (f == 0 | f == getFilas() - 1 | c == 0 | c == getColumnas() - 1) {
//                    System.out.print(PUNTO);
//                } else {
//                    System.out.print(BLANCO);
//                }
//            }
//            System.out.println("");
//        }
//
//    }
//        public void letraA() {
//        for (int f = 0; f < getFilas(); f++) {
//            for (int c = 0; c < getColumnas(); c++) {
//                if (f == 0 | f == getFilas() / 2 | c == 0 | c == getColumnas() - 1) {
//                    System.out.print(PUNTO);
//                } else {
//                    System.out.print(BLANCO);
//                }
//            }
//            System.out.println("");
//        }
//
//    }
//        
//            public void letraL() {
//        for (int f = 0; f < getFilas(); f++) {
//            for (int c = 0; c < getColumnas(); c++) {
//                if (f == getFilas() - 1 | c == 0) {
//                    System.out.print(PUNTO);
//                } else {
//                    System.out.print(BLANCO);
//                }
//            }
//            System.out.println("");
//        }
//
//    }
    private boolean esEsqInfIzq(int f, int c) {
        return f == uFila() && c == pColu();
    }

    private boolean esEsqInfDer(int f, int c) {
        return f == uFila() && c == uColu();
    }

    private boolean esEsqSupIzq(int f, int c) {
        return f == pFila() && c == pColu();
    }

    private boolean esEsqSupDer(int f, int c) {
        return f == pFila() && c == uColu();
    }

    private boolean esEsquina(int f, int c) {
        return esEsqInfDer(f, c) || esEsqInfIzq(f, c) || esEsqSupDer(f, c)
                || esEsqSupIzq(f, c);
    }

    private int mColu() {
        return getColumnas() / 2;
    }

    private int mFila() {
        return getFilas() / 2;
    }

    private int pFila() {
        return 0;
    }

    private int uFila() {
        return getFilas() - 1;
    }

    private int pColu() {
        return 0;
    }

    private int uColu() {
        return getColumnas() - 1;
    }

    private void dibujarA() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if ((f == pFila() || f == mFila()  
                        || c == pColu() || c == uColu())
                        && !esEsqSupDer(f, c) && !esEsqSupIzq(f, c)) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }
    }

    private void dibujarB() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (f == pFila() && !esEsqSupDer(f, c) || f == mFila()
                        || f == uFila() || c == pColu() || c == uColu() && f > mFila()
                        || c == uColu() - 1 && f < mFila()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarC() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if ((f == pFila() || c == pColu() || f == uFila())
                        && !esEsqSupIzq(f, c) && !esEsqInfIzq(f, c)) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarD() {

        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if ((f == pFila() || f == uFila() || c == pColu()
                        || c == uColu()) && !esEsqSupDer(f, c)
                        && !esEsqInfDer(f, c)) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarE() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (f == uFila() || c == pColu() || f == pFila()
                        || f == mFila() && c <= uColu() - 2) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarF() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == pColu() || f == pFila()
                        || f == mFila() && c <= uColu() - 1) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarG() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (f == pFila() || f == uFila() || f == mFila() && c > mColu() + 1
                        || c == pColu() || c == uColu() && f > mFila()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarH() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (f == mFila() || c == pColu() || c == uColu()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarI() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == mColu() || f == pFila() || f == uFila()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarJ() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == mColu() + 2 || f == pFila() || c == pColu() && f >= mFila() + 2
                        || f == uFila() && c <= uColu() - 2) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarK() {

    }

    private void dibujarL() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == pColu() || f == uFila()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarM() {

    }

    private void dibujarN() {

    }

    private void dibujarO() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (f == pFila() || f == uFila() || c == pColu()
                        || c == uColu()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarP() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == pColu() || f == pFila() || c == uColu() && f <= mFila()
                        || f == mFila()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarQ() {

    }

    private void dibujarR() {

    }

    private void dibujarS() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if ((c == pColu() && f <= mFila() || f == pFila() || f == uFila()
                        || f == mFila() || c == uColu() && f >= mFila())
                        && !esEsqSupIzq(f, c) && !esEsqInfDer(f, c)) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarT() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == mColu() || f == pFila()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarU() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (f == uFila() || c == pColu() || c == uColu()) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarV() {

    }

    private void dibujarW() {

    }

    private void dibujarX() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == uColu() - f + 1 || f == c + 1
                        || esEsquina(f, c)) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }

    private void dibujarY() {

    }

    private void dibujarZ() {
        for (int f = pFila(); f <= uFila(); f++) {
            for (int c = pColu(); c <= uColu(); c++) {
                if (c == uColu() - f + 1 || f == pFila() 
                        || f == uFila () || esEsquina(f, c)) {
                    setElem(f, c, PUNTO);
                } else {
                    setElem(f, c, BLANCO);
                }
            }
        }

    }
    
    public String strFila(int filaParaCartel) {
        String s = " ";

        for (int c = pColu(); c <= uColu(); c++) {
            s = s + dibujo[filaParaCartel][c];
        }

        return s;
    }

}
