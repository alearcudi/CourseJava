/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComponenteClase;

/**
 *
 * @author Richard
 */
public abstract class Cliente {

    private String codCliente;
    private String nomDocumento; // RECORDAR QUE TENOG Q CAMBIAR EN LA BD
    private String numDocumento;//recorda que tenog que cambiar en la BD
    private String nombre;
    private String telefono;

    /**
     * @return the codCliente
     */
    public String getCodCliente() {
        return codCliente;
    }

    /**
     * @param codCliente the codCliente to set
     */
    public void setCodCliente(String codCliente) {
        this.codCliente = codCliente;
    }

    /**
     * @return the nomDocumento
     */
    public String getNomDocumento() {
        return nomDocumento;
    }

    /**
     * @param nomDocumento the nomDocumento to set
     */
    public void setNomDocumento(String nomDocumento) {
        this.nomDocumento = nomDocumento;
    }

    /**
     * @return the numDocumento
     */
    public String getNumDocumento() {
        return numDocumento;
    }

    /**
     * @param numDocumento the numDocumento to set
     */
    public void setNumDocumento(String numDocumento) {
        this.numDocumento = numDocumento;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
