
package javaapplication585;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class Main {

    public static void main(String[] args) {
        Coleccion<String> lista = new Coleccion(1);
        
        lista.add("pepe1");
        lista.add("pepe2");
        lista.add("pepe3");
        lista.add("pepe4");
        lista.add("pepe5");
        lista.add("pepe6");
        lista.add("pepe7");
        lista.add("pepe8");
        lista.add("pepe9");
        lista.add("pepe10");
        System.out.println(lista);
        
        System.out.println("TAMANIO: " +lista.size());
        
        System.out.println(lista);
        
        if(lista.existe("pepe6")){
            lista.eliminar("pepe6");
        }
        
        System.out.println(lista);
        
        lista.limpiar();
        
        System.out.println(lista);        
        Coleccion <Integer> listae= new Coleccion();
        
        listae.add(1);
        listae.add(2);
        listae.add(3);
        listae.add(4);
        listae.add(5);
        listae.add(6);
        listae.add(7);
        listae.add(8);
        listae.add(9);
        listae.add(10);
        System.out.println("TAMANIO: " +listae.size());
        
        System.out.println(listae);
        
        if(listae.existe((Integer)7)){
            listae.eliminar((Integer)7);
        }
        
        System.out.println(listae);
        
        listae.limpiar();
        
        System.out.println(listae);
        
        
       List x = new ArrayList();
       
        x = new LinkedList();
        x = new Vector();
        
    }
    
}
