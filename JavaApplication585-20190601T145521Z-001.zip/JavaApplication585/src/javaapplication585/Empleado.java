/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication585;

/**
 *
 * @author ITMaster
 */
public class Empleado {
    private int legajo;
    private double sueldo;

    public Empleado(int legajo, double sueldo) {
        this.legajo = legajo;
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "Empleado{" + "legajo=" + legajo + ", sueldo=" + sueldo + '}';
    }

    public int getLegajo() {
        return legajo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setLegajo(int legajo) {
        this.legajo = legajo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
}
