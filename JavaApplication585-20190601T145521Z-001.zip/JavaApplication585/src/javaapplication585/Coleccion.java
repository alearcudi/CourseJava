package javaapplication585;

public class Coleccion<T> {
    
    private static final int TAMANIO_DEFECTO=10;
    private Object[] losDatos;
    private int proximo;

    public Coleccion(int tamanio) {
        proximo = 0;
        losDatos = new Object[tamanio];
    }

    public Coleccion() {
        this(TAMANIO_DEFECTO);
    }
    
    
    public void eliminar(T e){
        int posicion = buscar(e);
        
        if (posicion != -1) {
           eliminar(posicion); 
        }
    }
    public void eliminar(int posicion){
        for (int i = posicion; i < proximo-1; i++) {
            losDatos[i] = losDatos[i+1];
        }
        proximo--;
    }
    
    public int size(){
        return proximo;
    }
     
    public int limpiar(){
        int cant = size();
        
        proximo = 0;
        losDatos = new Object[TAMANIO_DEFECTO];
        
        return cant;
    }
    
    public boolean existe(T e){
        for (int i = 0; i < proximo; i++) {
            if(losDatos[i].equals(e)){
                return true;
            }
        }
        return false;
    }
    
    private int buscar(T e){
        for (int i = 0; i < proximo; i++) {
            if(losDatos[i].equals(e)){
                return i;
            }
        }
        return -1;
    }
    
    public T get(int posicion){
        return (T) losDatos[posicion];
    }
    
    public void set(int posicion,T e){
        losDatos[posicion] = e;
    }
    
    public boolean add(T e){
        if (proximo == losDatos.length) {
            Object[] aux = new Object[losDatos.length*2];
            for (int i = 0; i < losDatos.length; i++) {
                aux[i]=losDatos[i];
            }
            losDatos = aux;
        }
        losDatos[proximo++]=e;
        return true;
    }

    @Override
    public String toString() {
        String cadena = "[";
        
        for (int i = 0; i < proximo; i++) {
            if (i<proximo-1) {
                cadena = cadena + losDatos[i].toString() + ",";
            }
            else{
                cadena = cadena + losDatos[i].toString();
            }
        }
        return cadena +   "]";
    }
    
    
    
}
