package utilidades;

import java.util.Calendar;
import java.util.GregorianCalendar;
//LocalDate
public class Fecha
{
    private int dia;
    private int  mes;
    private int  anio;

    public Fecha(int dia, int mes, int anio){
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public Fecha(){
        //Creamos un objeto de la clase Calendar.
        Calendar fecha = new GregorianCalendar();
        //Obtenemos el valor del año, mes, día, hora, minuto y segundo del sistema.
        //Usando el método get y el parámetro correspondiente.
         anio = fecha.get(Calendar.YEAR);
         mes = fecha.get(Calendar.MONTH)+1;
         dia = fecha.get(Calendar.DAY_OF_MONTH);
    }

    public static Fecha getInstancia(String cartel){
        Fecha f = new Fecha();
        
        System.out.println(cartel);
        f.dia = Teclado.leerInt("Dia : ", 1, 31);
        f.mes = Teclado.leerInt("Mes : ", 1, 12);
        f.anio = Teclado.leerInt("Anio: ", 1900, 2100);
        return f;
    }

    public static Fecha getInstancia(){
        Fecha f = new Fecha();
        
        System.out.println("FECHA");
        f.dia = Teclado.leerInt("Dia : ", 1, 31);
        f.mes = Teclado.leerInt("Mes : ", 1, 12);
        f.anio = Teclado.leerInt("Anio: ", 1900, 2100);
        return f;
    }
    
    
    
    public int getDia(){return dia;}
    public void setDia(int dia){this.dia = dia;}
    public int getMes(){return mes;}
    public void setMes(int mes){this.mes = mes;}
    public int getAnio(){return anio;}
    public void setAnio(int anio){this.anio = anio;}
    private int fecha;

   


    
    

    public boolean esValida()
    {
        // 9999 99 99
        
        int m = getMes();
        if (m < 1 || m > 12)
        {
            return false;
        }
        
        int a = getAnio();
        if (a < 1800 || a > 2100)
        {
            return false;
        }
        
        int d = getDia();
        int diasDelMes = getLosDiasDelMes(m,a);
        
        if (d < 1 || d > diasDelMes)
        {
            return false;
        }
        return true;
    }

    public String getFechaCorta()
    {
        return String.format("%02d/%02d/%04d",getDia(),getMes(),getAnio());
    }
    
    public String getFechaLarga()
    {
        return String.format("%02d de %-10s de %04d",getDia(),
                getNombreMes(),getAnio());
        
    }


    private static int getLosDiasDelMes(int m, int a)
    {
        int dias = 0;
        switch(m)
        {
            case 1:  dias=31;  break;
            case 2:
            {
                if(esBisiesto(a))
                {
                    dias = 29;
                }
                else
                {
                    dias=28;
                }
            }
            break;
            case 3: dias=31;  break;
            case 4: dias=30;  break;
            case 5: dias=31;  break;
            case 6: dias=30;  break;
            case 7: dias=31;  break;
            case 8: dias=31;  break;
            case 9: dias=30;  break;
            case 10: dias=31; break;
            case 11: dias=30; break;
            case 12: dias=31; break;
        }
        
        return dias;
    }

    private static boolean esBisiesto(int a)
    {
       return  (a % 400 == 0) || (a % 4 == 0 && a % 100 != 0);
    }

    public static Fecha getFechaRandom(int unAnio)
    {
        int mes = enteroRandom(1,12);
        int dia = enteroRandom(1,getLosDiasDelMes(mes, unAnio));
        
        return new Fecha(dia,mes,unAnio);
    }
    public static Fecha getFechaRandom()
    {
        int unAnio= enteroRandom(1999,2030);
        int mes = enteroRandom(1,12);
        int dia = enteroRandom(1,getLosDiasDelMes(mes, unAnio));
        
        return new Fecha(dia,mes,unAnio);
    }

    public String getNombreMes()
    {
        String [] losMeses = {"error","enero","febrero","marzo"
                                     ,"abril","mayo"
                                     ,"junio","julio","agosto"
                                     ,"septiembe","octubre","noviembre"
                                     ,"diciembre"};
        
        return losMeses[getMes()];
    }
    
    private static int enteroRandom(int desde, int hasta)
    {
        return (int) (Math.random()*(hasta-desde+1)+desde);
    }
}
