package Controlador;

import Modelo.Articulo;
import java.util.ArrayList;
import utilidades.Fecha;
import utilidades.Selector;

public class Empresa {
    private static final int TERMINAR = 99;
    private static final int AGREGAR_ARTICULOS   = 1;
    private static final int CONSULTAR_ARTICULO  = 2;
    private static final int ELIMINAR_ARTICULOS  = 3;
    private static final int MODIFICAR_ARTICULOS = 4;
    private static final int LISTAR_ARTICULOS    = 5;
    private static final int NO_ENCONTRADO    = -1;
    String nombre;
    ArrayList<Articulo>losArticulos;

    public Empresa(String nombre) {
        this.nombre = nombre;
        losArticulos = new ArrayList();
                
    }
    
    public void menu(){
        
        int opcion1=0;
        
        do {
            opcion1 = new Selector("MENU PRINCIPAL "+ new Fecha().getFechaCorta()
                    +",Agregar,Consultar,Eliminar,Modificar,Listar").getOpcion();
            switch(opcion1){
                case AGREGAR_ARTICULOS:
                    agregarUnArticulo();
                break;    
                case CONSULTAR_ARTICULO:
                    agregarUnArticulo();
                break;    
                case ELIMINAR_ARTICULOS:
                    agregarUnArticulo();
                break;    
                case MODIFICAR_ARTICULOS:
                    agregarUnArticulo();
                break;    
                case LISTAR_ARTICULOS:
                    agregarUnArticulo();
                break;    
            }
        } while (opcion1 != TERMINAR);
        
    }

    private void agregarUnArticulo() {
        
    }
    
    
    
}
