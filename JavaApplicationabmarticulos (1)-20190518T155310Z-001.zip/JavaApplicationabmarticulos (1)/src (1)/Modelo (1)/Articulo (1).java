package Modelo;

public abstract class Articulo extends Object {
    protected int    codigo;
    protected String descripcion;
    protected double precioBase;
    protected int    stock;

    public Articulo() {
        super();
    }
  
    
    //LOS ATRIBUTOS ==> "codigo,descripcion,precioBase,stock"
    //SEPARADOS     ==> ["codigo","descripcion","precioBase","stock"]
    //                       0           1            2         3
    public Articulo(String losAtributos) {
        super();
        String []separados = losAtributos.split(",");
        codigo = Integer.valueOf(separados[0]);
        descripcion = separados[1];
        precioBase = Double.valueOf(separados[2]);
        stock = Integer.valueOf(separados[3]);
        
    }

    public Articulo(int codigo, String descripcion, double precioBase, int stock) {
        super();
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precioBase = precioBase;
        this.stock = stock;
    }

    @Override
    public String toString() {
        return  codigo + "," + descripcion + "," + precioBase + ","+stock+",";
    }
    
    public abstract double precioFinal();

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
}
