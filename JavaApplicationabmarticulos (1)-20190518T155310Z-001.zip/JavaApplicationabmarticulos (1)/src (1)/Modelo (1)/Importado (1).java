/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import utilidades.Teclado;

/**
 *
 * @author ITMaster
 */
public final class Importado extends Articulo{
    protected double impuesto;
    protected String paisOrigen;

    public Importado(int codigo, String descripcion, double precioBase, 
            int stock,double impuesto, String paisOrigen ) {
        super(codigo, descripcion, precioBase, stock);
        this.impuesto = impuesto;
        this.paisOrigen = paisOrigen;
    }

    public Importado() {
        super();
    }

    public Importado(String losAtributos) {
        super();       
        String []separados = losAtributos.split(",");
        
        codigo      = Integer.valueOf(separados[0]);
        descripcion = separados[1];
        precioBase  = Double.valueOf(separados[2]);
        stock       = Integer.valueOf(separados[3]);
        impuesto    = Double.valueOf(separados[4]);
        paisOrigen  = separados[5];

    }

    public static Importado leerUnArticulo(){
        Importado i = new Importado();
        
        i.codigo = Teclado.leerInt("Codigo <10000..15000>: ", 10000, 15000);
        
        return i;
    }
    public static Importado leerUnArticulo(int codigo){
        Importado i = new Importado();
        
        i.codigo = codigo;
        
        return i;
    }
    
    @Override
    public String toString() {
        return super.toString() + impuesto + "," + paisOrigen;
    }

    
    
    @Override
    public double precioFinal() {
       
        return precioBase + (impuesto*precioBase);
    }

    public double getImpuesto() {
        return impuesto;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    public void setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
    }
    
}
