package javaapplicationabmarticulos;

import Controlador.Empresa;


public class Main {

    public static void main(String[] args) {

       Empresa e = new Empresa("Libreria San Pirulo");
       
       e.menu();
        
        
        
        
    }
    
}
