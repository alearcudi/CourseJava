package javaapplication584;

public class Coleccion<T> {

    private static final int NO_ENCONTRADO = -1;
    private static final int TAMANIO_INICIAL = 10;
    private static final int FACTOR_INCREMENTO = 2;
    private Object[] losDatos;
    private int tamanio;

    public Coleccion(int tamanioInicial) {
        losDatos = new Object[tamanioInicial];
        this.tamanio = 0;
    }

    public Coleccion() {
        this(TAMANIO_INICIAL);
    }

    public T get(int posicion) {
        return (T) losDatos[posicion];
    }

    public boolean add(T e) {
        if (tamanio >= losDatos.length) {
            Object[] aux = new Object[losDatos.length * FACTOR_INCREMENTO];
            for (int i = 0; i < losDatos.length; i++) {
                aux[i] = losDatos[i];
            }
            losDatos = aux;
        }
        losDatos[tamanio] = e;
        tamanio++;
        return true;
    }

    @Override
    public String toString() {
        String s = "Coleccion\n";

        for (int i = 0; i < tamanio; i++) {
            s += losDatos[i].toString() + "\n";
        }

        return s;
    }

    public void mostrar() {

        for (int i = 0; i < tamanio; i++) {
            System.out.println(losDatos[i]);
        }
    }

    public int buscar(T e) {
        for (int posEncontrado = 0; posEncontrado < tamanio; posEncontrado++) {
            if (e.equals(losDatos[posEncontrado])) {
                return posEncontrado;
            }
        }
        return NO_ENCONTRADO;
    }

    public boolean existe(T e) {
        for (int posEncontrado = 0; posEncontrado < tamanio; posEncontrado++) {
            if (e.equals(losDatos[posEncontrado])) {
                return true;
            }
        }
 
        return false;
    }

    public void eliminar(int posicion) {
        for (int i = posicion; i < tamanio; i++) {
            losDatos[i] = losDatos[i + 1];
        }
        tamanio--;
    }
    
    public void eliminar(T e) {
        int posEliminar = buscar(e);
        
        if (posEliminar != NO_ENCONTRADO) {
            eliminar(posEliminar);
        }
    }

    

    public int tamanio() {
        return tamanio;
    }


    private boolean vacio() {
        return tamanio == 0;
    }


}
