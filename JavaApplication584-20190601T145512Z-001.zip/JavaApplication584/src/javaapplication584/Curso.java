/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication584;

import java.util.Scanner;

/**
 *
 * @author ITMaster
 */
public class Curso {
    
    private Coleccion<Alumno> losAlumnos;

    public Curso() {
        losAlumnos = new Coleccion();
    }
    
    public void modificar(){
        Scanner teclado = new Scanner(System.in);
        int legajo ;
        int nota;
        System.out.println("Ing legajo: ");legajo = teclado.nextInt();
        
        Alumno x = buscar(legajo);
        if (x!=null) {
            System.out.println("Nuevo legajo: ");legajo = teclado.nextInt();
            System.out.println("Nueva nota: ");nota = teclado.nextInt();
            x.setLegajo(legajo);
            x.setNota(nota);
        }
        
        
    }
    
    private Alumno buscar(int legajo){
        for (int i = 0; i < losAlumnos.tamanio(); i++) {
            if (legajo == losAlumnos.get(i).getLegajo()) {
                return losAlumnos.get(i);
            }
        }
        return null;
        
    }
    
    public void gregar(Alumno a){
        losAlumnos.add(a);
     
    }
    
    
    public void mostrar(){
       losAlumnos.mostrar();
    }
    
}
