/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication584;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ITMaster
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> lista = new ArrayList();
       
        Collection <String>listax = ArrayList();
        
        lista.add("pepe");
        lista.add("pepe");
        lista.add("pepe");
        lista.add("pepe");
        lista.add("pepe");
        lista.add("pepe");
        
        System.out.println(lista);
        
        Coleccion<Integer>lista1 = new Coleccion();
        
        
        lista1.add(2);
        lista1.add(1);
        lista1.add(20);
        lista1.add(112);
        lista1.add(233);
        
        System.out.println(lista1);
        
        Curso c = new Curso();
        
        c.gregar(Alumno.getInstance());
        c.gregar(Alumno.getInstance());
        c.gregar(Alumno.getInstance());
        c.gregar(Alumno.getInstance());
        c.gregar(Alumno.getInstance());
        
        c.mostrar();
        c.gregar(new Alumno(102,5));
        c.mostrar();
        
        c.modificar();
        c.mostrar();
        
    }

    private static List<String> ArrayList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static List<String> LinkedList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
