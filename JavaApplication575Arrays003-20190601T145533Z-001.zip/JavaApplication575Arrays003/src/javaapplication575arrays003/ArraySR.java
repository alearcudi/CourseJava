package javaapplication575arrays003;

import java.util.ArrayList;

public class ArraySR<T> extends ArrayList<T> {
    
    @Override
    public boolean add(T dato){
        if (this.contains(dato)) {
            return false;
        }
        return super.add(dato);
    }
    
}
