/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication575arrays003;

import java.util.ArrayList;

/**
 *
 * @author ITMaster
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
               ArrayList<String> listaString = new ArraySR();
       
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe1");
        listaString.add("pepe");
        listaString.add("pepe2");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe3");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");
        listaString.add("pepe");

        System.out.println("listaString: " + listaString);

    }
    
}
