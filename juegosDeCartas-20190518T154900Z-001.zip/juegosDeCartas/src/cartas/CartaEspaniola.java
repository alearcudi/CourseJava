package juegosdecartas;

public class CartaEspaniola {
    
}
