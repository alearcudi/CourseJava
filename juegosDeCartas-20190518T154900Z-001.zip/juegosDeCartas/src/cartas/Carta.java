package juegosDeCartas.cartas;

public abstract class Carta {
    protected int numero;
    protected int palo;

    public Carta(int numero, int palo) {
        this.numero = numero;
        this.palo = palo;
    }

    @Override
    public String toString() {
        return "[" +  elDibujoDelNumero() +  elDibujoDelPalo() + "]";
    }

    public int getNumero() {
        return numero;
    }

    public int getPalo() {
        return palo;
    }

    public int compareTo(Carta c){
        return numero-c.numero;
    }
    public abstract String elDibujoDelNumero();

    public abstract String elDibujoDelPalo();
    
    
    
}
