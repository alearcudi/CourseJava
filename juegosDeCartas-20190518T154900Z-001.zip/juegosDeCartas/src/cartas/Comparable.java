package cartas;

public interface Comparable {
    int compareTo(Carta otra);
}
