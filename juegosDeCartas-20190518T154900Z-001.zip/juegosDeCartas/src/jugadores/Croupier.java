package jugadores;

public class Croupier extends JugadorBlackJack{

    public Croupier(String nombre) {
        super(nombre);
    }

    @Override
    public boolean mePlanto() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
