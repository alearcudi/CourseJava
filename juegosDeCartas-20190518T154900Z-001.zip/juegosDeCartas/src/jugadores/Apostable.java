package jugadores;

interface Apostable {
    int apostar();
}
