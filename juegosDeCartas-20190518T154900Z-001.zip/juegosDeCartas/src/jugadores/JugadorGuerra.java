/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jugadores;

import juegosDeCartas.cartas.Carta;
import juegosdecartas.CartaPoker;
import mazos.MazoPoker;

/**
 *
 * @author ITMaster
 */
public class JugadorGuerra extends JugadorCartas{

    public JugadorGuerra(String nombre)
    {
        super(nombre);
        mano = new MazoPoker();
    }

    public void setCarta(Carta c)
    {
        mano.set(c);
    }
    public CartaPoker getCarta()
    {
        return (CartaPoker) mano.get();
    }

    public boolean tieneCartas()
    {
        return !mano.vacio();
    }

    public int cantCartas()
    {
        return mano.cantCartas();
    }

    
    
    
}
