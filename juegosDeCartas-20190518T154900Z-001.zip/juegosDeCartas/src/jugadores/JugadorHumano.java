/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jugadores;

import util.Teclado;

/**
 *
 * @author ITMaster
 */
public final class JugadorHumano extends JugadorCliente{

    public JugadorHumano(String nombre,int fichas) {
        super(nombre,fichas);
    }

    @Override
    public boolean mePlanto() {
        return Teclado.leerChar("Se planta (S/N)? ", "SsNn")=='S';
        
    }

    @Override
    public int apostar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
