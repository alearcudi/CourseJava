package jugadores;

import mazos.MazoBlackJack;

public abstract class JugadorBlackJack extends JugadorCartas implements Plantable{

    public JugadorBlackJack(String nombre) {
        super(nombre);
        mano = new MazoBlackJack();
    }

    
}
