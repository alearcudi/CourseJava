/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jugadores;

/**
 *
 * @author ITMaster
 */
public abstract class JugadorCliente extends JugadorBlackJack implements Apostable{
    protected int fichas;
    
    
    public JugadorCliente(String nombre,int fichas) {
        super(nombre);
        this.fichas = fichas;
    }

    public int getFichas() {
        return fichas;
    }

    public void ganarFichas(int fichas) {
        this.fichas += fichas;
    }
    public void perderFichas(int fichas) {
        this.fichas -= fichas;
    }
    
    public boolean tieneFichas(){
        return fichas > 0;
    }
}
