
package juegos;

import juegosDeCartas.cartas.Carta;
import jugadores.JugadorGuerra;
import mazos.MazoPoker;


public class Guerra
{
    JugadorGuerra jugadorUno;
    JugadorGuerra jugadorDos;
    MazoPoker elMazo;
    
    
    public Guerra(String nombreJugadorUno, String nombreJugadorDos)
    {
        jugadorUno = new JugadorGuerra(nombreJugadorUno);
        jugadorDos = new JugadorGuerra(nombreJugadorDos);
        elMazo = new MazoPoker();
        elMazo.llenar();
        
    }

    public void jugar(){
        MazoPoker pilaEnLaMesa = new MazoPoker();
        boolean terminarPorGanador = false;
        boolean hayUnEmpate = false;
        Carta cartaJugadorUno;
        Carta cartaJugadorDos;
        
        repartirLaMitadDelMazoParaCadaJugador();
        //SACA UNA CARTA CADA JUGADOR
        cartaJugadorUno=jugadorUno.getCarta();
        cartaJugadorDos=jugadorDos.getCarta();
        while(!terminarPorGanador){//MIENTRAS NO HAY GANADOR            
            System.out.println(jugadorUno.getNombre()+ " " + cartaJugadorUno);
            System.out.println(jugadorDos.getNombre()+ " " + cartaJugadorDos);
            if (cartaJugadorUno.compareTo(cartaJugadorDos)>0) {//GANA EL JUGADOR UNO?
                System.out.println("GANA "+jugadorUno.getNombre());
                //SI VENIMOS DE UN EMPATE  ENTRAMOS AL WHILE
                while(!pilaEnLaMesa.vacio()){//TOMAMOS TODAS LAS CARTAS DE LA MESA
                    jugadorUno.setCarta(pilaEnLaMesa.get());
                }
                jugadorUno.setCarta(cartaJugadorUno);
                jugadorUno.setCarta(cartaJugadorDos);
                jugadorUno.getMano().mezclar();
            }
            else{
                if (cartaJugadorDos.compareTo(cartaJugadorUno)>0) {//GANA EL JUGADOR DOS?
                    //SI VENIMOS DE UN EMPATE  ENTRAMOS AL WHILE
                    while(!pilaEnLaMesa.vacio()){//TOMAMOS TODAS LAS CARTAS DE LA MESA
                        jugadorDos.setCarta(pilaEnLaMesa.get());
                    }
                    System.out.println("GANA "+jugadorDos.getNombre());
                    jugadorDos.setCarta(cartaJugadorUno);
                    jugadorDos.setCarta(cartaJugadorDos);
                    jugadorDos.getMano().mezclar();
                }
                else{//LAS CARTAS EMPATAN (1eR EMPATE)
                    hayUnEmpate = true;
                    System.out.println("EMPATE");
                    System.out.println(cartaJugadorUno +" "+cartaJugadorDos);
                    while(!terminarPorGanador && cartaJugadorUno.compareTo(cartaJugadorDos)==0){
                        pilaEnLaMesa.set(cartaJugadorUno);
                        pilaEnLaMesa.set(cartaJugadorDos);
                        if (jugadorUno.tieneCartas()) {
                            pilaEnLaMesa.set(jugadorUno.getCarta());//LA CARTA TAPADA
                            System.out.println(jugadorUno.getNombre()+ " " + "[ ]");
                            if (jugadorUno.tieneCartas()) {
                                cartaJugadorUno = jugadorUno.getCarta();
                            }
                            else{
                                terminarPorGanador = true;
                                System.out.println(jugadorUno.getNombre()+ " Sin Cartas!!!" );
                            }
                        }
                        else{
                            terminarPorGanador = true;
                            System.out.println(jugadorUno.getNombre()+ " Sin Cartas!!!" );
                        }
                        if (!terminarPorGanador) {
                            if (jugadorDos.tieneCartas()) {
                                pilaEnLaMesa.set(jugadorDos.getCarta());
                                System.out.println(jugadorDos.getNombre()+ " " + "[ ]");
                                if (jugadorDos.tieneCartas()) {
                                    cartaJugadorDos = jugadorDos.getCarta();
                                }
                                else{
                                    terminarPorGanador = true;
                                    System.out.println(jugadorDos.getNombre()+ " Sin Cartas!!!" );
                                }
                            }
                            else{
                                terminarPorGanador = true;
                                System.out.println(jugadorDos.getNombre()+ " Sin Cartas!!!" );
                            }
                        }
                    }
                }
            }
            if(hayUnEmpate){
                hayUnEmpate = false;
            }
            else{
                if (jugadorUno.tieneCartas()) {
                    cartaJugadorUno=jugadorUno.getCarta();
                }
                else{
                    terminarPorGanador = true;
                }
                if (jugadorDos.tieneCartas()) {
                    cartaJugadorDos=jugadorDos.getCarta();
                }
                else{
                    terminarPorGanador = true;
                }
            }
        }
        if (jugadorUno.tieneCartas()) {
            System.out.println("GANADOR: " +jugadorUno.getNombre() );
        }
        else{
            System.out.println("GANADOR: " +jugadorDos.getNombre());
        }
        System.out.println("PARA TERMINAR!!!!!!");
        System.out.println(jugadorUno);
        System.out.println(jugadorDos);
        System.out.println("Cantidad Cartas jugadorUno " + jugadorUno.cantCartas());
       System.out.println("Cantidad Cartas jugadorDos " + jugadorDos.cantCartas());
    }

    private void repartirLaMitadDelMazoParaCadaJugador()
    {
        elMazo.mezclar();
        while(!elMazo.vacio()){
            jugadorUno.setCarta(elMazo.get());
            jugadorDos.setCarta(elMazo.get());
        }
    }
    
}
