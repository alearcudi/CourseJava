package juegos;

import java.util.ArrayList;
import jugadores.JugadorCliente;
import jugadores.Croupier;
import mazos.MazoBlackJack;

public class BlackJack {
    
    private MazoBlackJack elMazo;
    private Croupier elCroupier;
    private ArrayList<JugadorCliente>losJugadores;
    
    public BlackJack(){
        elMazo = new MazoBlackJack();
        elMazo.llenar();
        elCroupier = new Croupier("Sr. Croupier");
        losJugadores = new ArrayList();
    }
    
    public void agregarJugador(JugadorCliente cliente){
        losJugadores.add(cliente);
    }
    
    public void jugar(){
        
    }
}
