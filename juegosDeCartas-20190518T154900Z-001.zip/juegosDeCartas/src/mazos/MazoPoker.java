/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mazos;

import juegosdecartas.CartaPoker;

/**
 *
 * @author ITMaster
 */
public final class MazoPoker extends Mazo{

    public MazoPoker() {
        super();
    }
    
    @Override
    public void llenar() {
        for (int numero = 1; numero <= 13; numero++) {
            for (int palo = 1; palo <= 4; palo++) {
                set(new CartaPoker(numero,palo));
            }
        }
    }
    
}
