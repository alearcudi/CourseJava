/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication274coleccionesgenericas;



/**
 *
 * @author ITMaster
 */
public class Juego
{
    
    private Coleccion<Jugador> jugadores;
    private Mazo mazo;

    public Juego()
    {
        jugadores = new Coleccion(1);
        agregarJugador("CRUPIERE");
        mazo = new Mazo();
        mazo.llenarMazo();
        mazo.mezclar();
        
    }

    @Override
    public String toString() {
        return "Juego{" + "jugadores=" + jugadores + ", mazo=" + mazo + '}';
    }

    public Coleccion<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(Coleccion<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    public Mazo getMazo() {
        return mazo;
    }

    public void setMazo(Mazo mazo) {
        this.mazo = mazo;
    }

    public void agregarJugador(String nombre)
    {
        Jugador x = new Jugador(nombre);
        jugadores.add(x);
    }

    public void repartir(int cantCartas) {
        for (int c = 0; c < cantCartas; c++) {

            for (int i = 0; i < this.jugadores.size(); i++) {
                jugadores.get(i).getMano().poneUnaCarta(mazo.dameUnaCarta());

            }
        }
    }

    void jugar() 
    { 
        boolean flagMazo=true;
        boolean flagCarta=true;
        Carta cartaMax=null;
        Carta cartaMax2=null;
        Jugador jugadorMax=null;
        int maxNumero=0;
        int maxJugador=0;
        
        repartir(5);
        for (int i = 0; i < jugadores.size(); i++)
        {
            flagCarta = true;
            for (int c = 0; c < jugadores.get(i).getMano().getMazo().size(); c++) 
            {
                if (flagCarta||jugadores.get(i).getMano().getMazo().get(c).compareTo(cartaMax)>0) 
                {
                    cartaMax = jugadores.get(i).getMano().getMazo().get(c);
                    flagCarta = false;
                   
                }
            }
            
            if(flagMazo || cartaMax.compareTo(cartaMax2) > 0)
            {
                cartaMax2 = cartaMax;
                jugadorMax = jugadores.get(i);
                flagMazo = false;
            }
        }
        System.out.println("GANADOR: " + jugadorMax);
        System.out.println(this.toString());
    }
}
