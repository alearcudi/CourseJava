/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication274coleccionesgenericas;

/**
 *
 * @author ITMaster
 */
public class Heladera extends Producto implements Vendible,Usable
{
    
    private int marca;

    public Heladera(int marca, int codigo)
    {
        super(codigo);
        this.marca = marca;
    }

    @Override
    public String toString() 
    {
        return super.toString() + " Heladera{" + "marca=" + marca + '}';
    }

   

    public int getMarca() {
        return marca;
    }

    public void setMarca(int marca) {
        this.marca = marca;
    }

    
    
    @Override
    public void guardar()
    {
        System.out.println("GUARDANDO EN LA HELADERA");
    }

    @Override
    public void escupir() {
        
        System.out.println("LA HELADERA ESCUPE");
    }

    @Override
    public void recuperar()
    {
        System.out.println("HELADERA RECUPERADA");
    }
    @Override
    public int cuantoCuesta()
    {
        return 10000;
    }

    @Override
    public void pepe() 
    {
        System.out.println("usar!!!!!!!!");
    }

    
}
