
package javaapplication274coleccionesgenericas;

public interface Guardable{  
    int PEPE=0;
    
    void  guardar();
    void  recuperar();
}
