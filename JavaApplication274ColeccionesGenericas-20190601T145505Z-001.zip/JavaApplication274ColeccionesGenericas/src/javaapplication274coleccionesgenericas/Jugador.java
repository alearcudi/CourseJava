/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication274coleccionesgenericas;

import java.util.Objects;

/**
 *
 * @author ITMaster
 */
public class Jugador {
    
    private String nombre;
    private Mazo mano;

    
    @Override
    public boolean equals(Object elOtroObj)
    {
        if (elOtroObj == null) 
        {
            return false;
        }
        
        if (this.getClass() != elOtroObj.getClass()) 
        {
            return false;
        }
        
        final Jugador unJugador = (Jugador) elOtroObj;
        
        if (!Objects.equals(this.nombre, unJugador.nombre)) 
        {
            return false;
        }
        
        if (!Objects.equals(this.mano, unJugador.mano))
        {
            return false;
        }
        
        return true;
    }

    public Jugador(String nombre) 
    {
        this.nombre = nombre;
        mano = new Mazo();
    }

    @Override
    public String toString() {
        return "Jugador{" + "nombre=" + nombre + ", mano=" + mano + '}';
    }

    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Mazo getMano() {
        return mano;
    }

    public void setMano(Mazo mano) {
        this.mano = mano;
    }
    
    
}
