/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication274coleccionesgenericas;



/**
 *
 * @author ITMaster
 */
public class Carrito 
{
    Coleccion<Vendible> carrito;

    public Carrito(Coleccion<Vendible> carrito)
    {
        this.carrito = carrito;
    }

    public Carrito()
    {
        carrito = new Coleccion ();
    }
    
    public void agregar (Vendible item) 
    {
        carrito.add(item);
    }

    public int valor()
    {
        int suma = 0;
        for (int i = 0; i < carrito.size(); i++) 
        {
            suma = suma + carrito.get(i).cuantoCuesta();
        }
        return suma;
    }

    public String toString()
    {
        String s = "";
        for (int i = 0; i < carrito.size(); i++) {
            s += carrito.get(i).toString() + " \n";
        }
        return s;
    }

}
