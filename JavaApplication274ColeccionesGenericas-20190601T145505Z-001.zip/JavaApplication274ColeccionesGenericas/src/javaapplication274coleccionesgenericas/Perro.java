/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication274coleccionesgenericas;

/**
 *
 * @author ITMaster
 */
public class Perro implements Escupible,Vendible
{

    
    @Override
    public void escupir()
    {
        System.out.println("EL PERRO ESCUPE!!!!");
    }

    @Override
    public void guardar()
    {
        System.out.println("anda a la cucha!!!!");
    }

    @Override
    public void recuperar()
    {
        System.out.println("ui ui ui ui");
    }

    @Override
    public int cuantoCuesta()
    {
        return 100;
    }

    @Override
    public String toString()
    {
        return "Perro{" + '}';
    }
    
    
}
