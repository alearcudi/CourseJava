/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication274coleccionesgenericas;

/**
 *
 * @author ITMaster
 */
public class Carta implements Comparable,Guardable,Escupible,Vendible
{
    private int numero;
    private int palo;

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + this.numero;
        hash = 53 * hash + this.palo;
        return hash;
    }
    
    
    
    @Override
    public boolean equals(Object otroObjeto) {
        if (otroObjeto == null) {
            return false;
        }
        
        if (this.getClass() != otroObjeto.getClass()) {
            return false;
        }
        
        final Carta otraCarta = (Carta) otroObjeto;
        
        if (this.numero != otraCarta.numero) {
            return false;
        }
        if (this.palo != otraCarta.palo) {
            return false;
        }
        return true;
    }

   
    
    


    @Override
    public String toString() {
        return "[" + elNumero() + "," + elPalo() + "]";
    }

    public Carta(int numero, int palo) {
        this.numero = numero;
        this.palo = palo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getPalo() {
        return palo;
    }

    public void setPalo(int palo) {
        this.palo = palo;
    }

    private String elNumero() 
    {
        if(numero == 1)
        {
            return "A";
        }
        if(numero < 11)
        {
               return  String.valueOf(numero);
        }
        
        if(numero == 11)
        {
            return "J";
        }
        if(numero == 12)
        {
            return "Q";
        }
        return "K";
    }

    private String elPalo()
    {
        String s = "";
        if(palo == 1)
        {
            s = "♥";
        }
        else
        {
            if (palo == 2) 
            {
                s = "♦";
            }
            else
            {
                if (palo == 3) 
                {
                    s = "♣";
                }
                else
                {
                    s = "♠";
                }
            }
        }
        return s;
    }

    @Override
    public int compareTo(Object o) 
    {
             
        Carta c = (Carta) o;
        
        return this.numero - c.numero;
    }

    /**
     *
     */
    @Override
    public void guardar()
    {
        System.out.println("GUARDANDO UNA CARTA");
    }

    @Override
    public void escupir() {
        System.out.println("LA CARTA ESCUPIO");
    }

    @Override
    public void recuperar()
    {
        System.out.println("LA CARTA RECUPERADA");
    }

    @Override
    public int cuantoCuesta()
    {
        return 1;
     }
    
}
