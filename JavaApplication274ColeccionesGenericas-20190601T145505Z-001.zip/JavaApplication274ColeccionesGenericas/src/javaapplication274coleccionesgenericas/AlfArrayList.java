
package javaapplication274coleccionesgenericas;

import java.util.ArrayList;

public final class AlfArrayList<T> extends ArrayList<T> {

    @Override
    public boolean add(T dato) {
        if (this.contains(dato)) {
            return false;
        }

        return super.add(dato);
    }
}
