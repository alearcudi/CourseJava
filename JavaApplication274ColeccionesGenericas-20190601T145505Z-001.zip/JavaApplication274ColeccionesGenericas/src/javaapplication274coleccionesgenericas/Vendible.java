
package javaapplication274coleccionesgenericas;

public interface Vendible extends Guardable{
   int X = 0;
   int cuantoCuesta();
   @Override
   String toString();
}
