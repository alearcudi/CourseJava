package javaapplication274coleccionesgenericas;

import java.util.Arrays;

public class Coleccion<T> 
{

    private Object[] datos;
    private int largo;

    public int size()
    {
        return largo;
    }
    
    public Coleccion(int largoInicial)
    {
        this.largo = 0;
        this.datos = new Object[largoInicial];
    }
    
    public Coleccion()
    {
        this.largo = 0;
        this.datos = new Object[10];
    }

    public int existe(T elemento)
    {
        int i = 0;

        while (i < largo && !datos[i].equals(elemento)){
            i++;
        }
        return (i < largo) ? i : -1;
    }

    public void add(T elemento)
    {
        insertar(elemento, largo);
    }

    public T eliminar(int pos)
    {
        Object aux = datos[pos];

        for (int i = pos; i < largo - 1; i++)
        {
            datos[i] = datos[i + 1];
        }
        return (T) aux;
    }

    public T get(int pos)
    {
        return (T) datos[pos];
    }

    public void insertar(T elemento, int pos)
    {
        if (largo == datos.length)
        {

            Object[] aux = datos;
            datos = new Object[datos.length * 2];
            
            for (int i = 0; i < largo; i++)
            {
                datos[i] = aux[i];
            }
            aux = null;
        }

        for (int i = largo - 1; i >= pos; i--)
        {
            datos[i + 1] = datos[i];
        }

        datos[pos] = elemento;
        largo++;

    }

    @Override
    public String toString()
    {
        String s = "Coleccion: ";

        for (int i = 0; i < largo; i++)
        {
            s += datos[i].toString() + " , ";
        }
        return s + " ";
    }

    @Override
    public int hashCode()
    {
        int hash = 7;
        hash = 59 * hash + Arrays.deepHashCode(this.datos);
        hash = 59 * hash + this.largo;
        return hash;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        if (this.getClass() != obj.getClass())
        {
            return false;
        }
        final Coleccion<?> other = (Coleccion<?>) obj;
        if (!Arrays.deepEquals(this.datos, other.datos))
        {
            return false;
        }
        if (this.largo != other.largo)
        {
            return false;
        }
        return true;
    }

}

















