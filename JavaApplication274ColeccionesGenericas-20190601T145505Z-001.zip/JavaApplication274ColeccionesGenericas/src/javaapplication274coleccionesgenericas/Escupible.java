

package javaapplication274coleccionesgenericas;

public interface Escupible extends Guardable{
    int numero=1;
  
    void escupir();
}
