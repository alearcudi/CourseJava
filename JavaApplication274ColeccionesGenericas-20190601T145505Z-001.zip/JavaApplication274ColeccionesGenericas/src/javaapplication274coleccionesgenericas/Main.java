package javaapplication274coleccionesgenericas;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main
{

    public static void main(String[] args)
    {
        
//////        Coleccion<String> lista = new Coleccion();
//////           
//        List<String> lista;
//////           
////
////         ArrayList<  ArrayList<String>   > lista1 = new ArrayList();
//         lista = new LinkedList();
////           
//           lista.add("pepe");
//           lista.add("pepe");
//           lista.add("pepe1");
//           lista.add("pepe1");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe2");
//           lista.add("pepe3");
//           lista.add("pepe3");
//           
//          
//           
//           System.out.println("lista: " + lista);
//           
//           lista1.add(lista);
//           lista1.add(lista);
//           lista1.add(lista);
//           lista1.add(lista);
//           lista1.add(lista);
//           
//           System.out.println("lista1 "+lista1);
//        
//           
         
//           Coleccion <Coleccion<Vendible>  > pepe=new Coleccion();
//           
//           Coleccion<Vendible> juan = new Coleccion();
//            Coleccion<Vendible> rosa = new Coleccion();
//           
//           juan.add(new Carta(2,2));
//           juan.add(new TvLed(1234));
//           juan.add(new Carta(2,1));
//           juan.add(new Carta(2,3));
//           
//           rosa.add(new Heladera(20,29));
//           rosa.add(new Carta(4,4));
//           
//           
//           
//           pepe.add(juan);
//           pepe.add(rosa);
//           
//           
//           
//           pepe.add(juan);
//           
//           System.out.println(pepe);
         
//      
           Carrito c = new Carrito();
           
           c.agregar(new Heladera(123, 123));
           c.agregar(new Pancho());
           c.agregar(new Heladera(456, 456));
           c.agregar(new Pancho());
           c.agregar(new Heladera(789, 789));
           c.agregar(new Perro());
           c.agregar(new Carta(1, 1));
           c.agregar(new Perro());
           c.agregar(new Pancho());
           
           
           System.out.println(c);
           System.out.println("TOTAL: "+c.valor());

    }
    
}
