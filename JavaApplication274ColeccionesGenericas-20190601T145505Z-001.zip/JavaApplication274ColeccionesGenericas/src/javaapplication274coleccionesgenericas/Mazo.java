package javaapplication274coleccionesgenericas;



public class Mazo implements Vendible
{
    private Coleccion<Carta> mazo ;

    public Mazo()
    {
        mazo = new Coleccion(52);
    }
    
    public void llenarMazo()
    {
        for (int n= 1; n <= 13; n++) 
        {
            for (int p = 1; p <= 4; p++) 
            {
                getMazo().add(new Carta(n,p));
            }
        }
    }

    public Carta dameUnaCarta()
    {
        Carta aux =  getMazo().get(0);
        getMazo().eliminar(0);
        return aux;
    }
    
    public void poneUnaCarta(Carta c)
    {
        getMazo().add(c);
    }
    
    public void mezclar()
    {
        for (int i = 0; i < 1000; i++)
        {
            int x = intRand(0,getMazo().size()-1);
            
            Carta aux = getMazo().get(x);
            getMazo().eliminar(x);
            getMazo().add(aux);
        }
    }
    
    @Override
    public String toString() 
    {
        String s = "";
        for (int i = 0; i < getMazo().size(); i++) 
        {
            s+=getMazo().get(i).toString();
        }
        return s;
    }

    private int intRand(int d, int h)
    {
        return (int)(Math.random()*(h-d+1)+d);
    }

    public Coleccion<Carta> getMazo() {
        return mazo;
    }

    public void setMazo(Coleccion<Carta> mazo) {
        this.mazo = mazo;
    }

    @Override
    public int cuantoCuesta() {
        return 0;
    }

    @Override
    public void guardar() {
        System.out.println("Guardando");
    }

    @Override
    public void recuperar() {
        System.out.println("recuperando");
    }
    
    
}
