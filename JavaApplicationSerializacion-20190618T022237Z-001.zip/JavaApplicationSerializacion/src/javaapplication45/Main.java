
package javaapplication45;

import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException, ClassNotFoundException
    {
         new Manejador().manejar();
         Emeses x;
         
      
    }
    
}




