package javaapplication572vectores;
/*
 
 
 Se desea modelar una nueva clase en Java, que represente a los Vectores en
un espacio de 2 dimensiones. Para ello cada vector almacenara entre sus
atributos su componente en X y su componente en Y.
Además el Vector deberá ser probado desde JUnit con test Unitarios.
Los métodos a desarrollar serán mencionados en este archivo y explicados en
clase.


* int calcularProductoInterno(Vector otro)

Estos métodos devuelven un resultado entero.
void cambiarSentido()
void multiplicarPorEscalar(int factor)
Y estos últimos alteran al vector que llama a la función.
c) Crear un método boolean sonParalelos(Vector otro) que devuelva True si los
vectores son paralelos o no.

ACLARACIÓN: Dos vectores son paralelos cuando llevados al origen, uno es
múltiplo del otro.
 
 
 */
 
public class Vector {

    private double x;
    private double y;

    
    public Vector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }

    public int calcularMagnitud() {
        return (int)Math.sqrt(x * x + y * y);
    }

    public double angulo() {
        return Math.atan2(y, x);
    }

    public Vector sumar(Vector otro) {
        return new Vector(x + otro.x, y + otro.y);
    }

    public Vector restar(Vector otro) {
        return new Vector(x - otro.x, y - otro.y);
    }

    public boolean esIgual(Vector otro) {

        if (Double.doubleToLongBits(x) != Double.doubleToLongBits(otro.x)) {
            return false;
        }
        return Double.doubleToLongBits(y) == Double.doubleToLongBits(otro.y);
    }

    public int calcularProductoInterno(Vector otro) {
        return (int) ((x * otro.x) + (y * otro.y));
    }

    public boolean sonParalelos(Vector otro) {
        return (x * otro.y == y * otro.x);
    }

    public void cambiarSentido() {
      if(x!=0&&y!=0){
        x *= -1;
        y *= -1;
      }
    }

    public void multiplicarPorEscalar(int factor) {
        x *= factor;
        y *= factor;
        pepe();
    }
    
    
    public void met1(){
        throw new UnsupportedOperationException("Falta Terminar.");
    }
    public int met2(){
        throw new UnsupportedOperationException("Falta Terminar.");
    }

    private void pepe() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    

}
