/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication582alumnos;

/**
 *
 * @author ITMaster
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Alumno a = new Alumno("10101,7");
        
      
       System.out.println(a);
        
        
        
        Curso c = new Curso(100);
       
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        
        a = Alumno.getInstance();
        a.setLegajo(109);
        c.agregar(a);
        
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        c.agregar(Alumno.getInstance());
        
        c.mostrar();
        
        int e = c.buscar(109);
        
        c.eliminar(e);
        
        c.mostrar();
        
    }
    
}
