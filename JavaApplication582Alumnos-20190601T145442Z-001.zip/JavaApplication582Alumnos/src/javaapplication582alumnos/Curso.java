
package javaapplication582alumnos;


public class Curso {
    private static final int DIMENSION_DEFECTO = 20;
    private static final int NO_ENCONTRADO = -1;
    private Alumno [] losAlumnos;
    private int dimension;
    private int ultimo;

    public Curso(int dimension) {
        this.dimension = dimension;
        losAlumnos = new Alumno[dimension];
        ultimo = 0;
    }
    
    public Curso() {
        this.dimension = DIMENSION_DEFECTO;
        losAlumnos = new Alumno[DIMENSION_DEFECTO];
        ultimo = 0;
    }

    public void mostrar(){
        System.out.println("CURSO");
        
        if (!hayAlumnos()) {
            System.out.println("NO HAY ALUMNOS");
            return;
        }
        System.out.println(String.format("%-6s %-4s","LEGAJO","NOTA"));
        for (int i=0;i< ultimo;i++) {
            System.out.println(String.format("%6d %4d",losAlumnos[i].getLegajo()
                                                       ,losAlumnos[i].getNota()));
        }
        System.out.println("------- fin -------");
    }
    
    public boolean agregar(Alumno x){
        if (hayLugar()) {
            losAlumnos[ultimo]=x;
            ultimo++;
            return true;
        }
        return false;
    }
    
    public int buscar(int legajo){
        for (int posEncontrado = 0; posEncontrado < ultimo; posEncontrado++) {
            if (legajo == losAlumnos[posEncontrado].getLegajo()) {
                return posEncontrado;
            }
        }
        return NO_ENCONTRADO;
    }
    public boolean existe(int legajo){
        for (int i = 0; i < ultimo; i++) {
            if (legajo == losAlumnos[i].getLegajo()) {
                return true;
            }
        }
        return false;
    }
    
    public void eliminar(int posicion){
        for (int i = posicion; i < ultimo; i++) {
            losAlumnos[i] = losAlumnos[i+1];
        }
        ultimo--;
    }
    
    
    
    
    public int getDimension() {
        return dimension;
    }

    public int getUltimo() {
        return ultimo;
    }

    private boolean hayAlumnos() {
       return  ultimo>0;
    }
    private boolean vacio() {
       return  ultimo==0;
    }

    private boolean hayLugar() {
        return ultimo < dimension;
    }

    
    
}
