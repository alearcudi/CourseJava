package juegos;

import java.util.ArrayList;
import jugadores.Croupier;
import jugadores.JugadorCliente;
import mazos.MazoSieteYMedio;


public class SieteYMedio {
        private static final String LINEA = "--------------------------------------";
    
    private MazoSieteYMedio elMazo;
    private Croupier elCroupier;
    private ArrayList<JugadorCliente>losJugadores;
    
    private void linea(){
        System.out.println(LINEA);
    }
    
    public SieteYMedio(){
        elMazo = new MazoSieteYMedio();
        elMazo.llenar();
        elCroupier = new Croupier("Sr. Croupier");
        losJugadores = new ArrayList();
    }
    
    public void agregarJugador(JugadorCliente cliente){
        losJugadores.add(cliente);
    }
    
    public void jugar() {
        int suma=0;
       
        int[] elPozoDeLasApuestas;
        elMazo.mezclar();
        System.out.println(LINEA);
        System.out.println("COMIENZA EL JUEGO.");
        System.out.println(LINEA);
        while (hayJugadoresEnLaMesa()) {
            eliminarLosJugadoresSinFichas();
            elPozoDeLasApuestas = rondaDeApuestas();
            repartirUnaCarta();
            System.out.println(LINEA);
            System.out.println("JUEGAN LOS JUGADORES");
            System.out.println(LINEA);
            for (JugadorCliente jug : losJugadores) {
                suma = jug.laSumaDeLasCartas();
                System.out.println(jug.getNombre() + " " + jug.getMano() + " (" + suma + ")");
                while (suma <= 7 && !jug.sePlanta()) {
                    jug.tomaCarta(elMazo.get());
                    suma = jug.laSumaDeLasCartas();
                    System.out.println(jug.getNombre() + " " + jug.getMano() + " (" + suma + ")");
                }
                if (suma > 7.5) {
                    System.out.println("SE PASO!");
                }
               
            }
            System.out.println(LINEA);
            System.out.println("JUEGA EL CROUPIER");
            System.out.println(LINEA);
            suma = elCroupier.laSumaDeLasCartas();
            System.out.println(elCroupier.getNombre() + " " + elCroupier.getMano() + " (" + suma + ")");
            while (suma < 7.5 && !elCroupier.sePlanta()) {
                elCroupier.tomaCarta(elMazo.get());
                suma = elCroupier.laSumaDeLasCartas();
                System.out.println(elCroupier.getNombre() + " " + elCroupier.getMano() + "(" + suma + ")");
            }
            if (suma > 7.5) {
                System.out.println("SE PASO!");
            }
            
            repartirPremios(elPozoDeLasApuestas);
            limpiarCartas();
        }
    }

    private boolean hayJugadoresEnLaMesa() {
        return !losJugadores.isEmpty();
    }

    private void eliminarLosJugadoresSinFichas() {
        ArrayList<JugadorCliente> aux = new ArrayList();
        
        for (JugadorCliente jug : losJugadores) {
            if (jug.tieneFichas()) {
                aux.add(jug);
            }
            else{
                System.out.println(jug.getNombre()+" SE RETIRA!");
            }
        }
        
        losJugadores = null;
        losJugadores = aux;


    }

    private int[] rondaDeApuestas() {
        
        int []elPozo=new int[losJugadores.size()];
        for (int i = 0; i < elPozo.length; i++) {
            elPozo[i]=0;
        }
        System.out.println(LINEA);
        System.out.println("RONDA DE APUESTAS.");
        System.out.println(LINEA);
        int posEnLaMesa=0;
        for (JugadorCliente jug : losJugadores) {
            
            System.out.print(jug.getNombre()
                    +" TIENE: "+jug.getFichas());
            elPozo[posEnLaMesa] = jug.hacerApuesta();
                System.out.print(" APUESTA: "+elPozo[posEnLaMesa]+"\n");
            posEnLaMesa++;
        }
        return elPozo;
    }

    private void repartirUnaCarta() {
        System.out.println(LINEA);
        System.out.println("REPARTIENDO UNA CARTA A CADA JUGADOR");
        System.out.println(LINEA);
        for (JugadorCliente jug: losJugadores) {
            jug.getMano().set(elMazo.get());
            System.out.println(jug.getNombre()+" "+jug.getMano()+" ("+jug.laSumaDeLasCartas()+")");
        }
        System.out.println(LINEA);
        System.out.println("REPARTIENDO UNA CARTA AL CROUPIER");
        System.out.println(LINEA);
        elCroupier.getMano().set(elMazo.get());
        System.out.println(elCroupier.getNombre()+" "+elCroupier.getMano()+" ("+elCroupier.laSumaDeLasCartas()+")");
    }

    

    private void repartirPremios(int[] elpozo) {
        int sumaJugador=0;
        int sumaCroupier=elCroupier.laSumaDeLasCartas();
        int posicionJug=0;
        System.out.println(LINEA);
        System.out.println("REPARTIENDO PREMIOS");
        System.out.println(LINEA);
        
        
        for(JugadorCliente jug:losJugadores){
            System.out.println(elCroupier.getNombre()+" "+elCroupier.getMano()+
                " (" + sumaCroupier+")");    
            sumaJugador = jug.laSumaDeLasCartas();
            System.out.println(jug.getNombre()+" "+jug.getMano()+" (" +sumaJugador+")");
           
            if (sumaJugador==7.5 && jug.cantidadCartas()==2 ) {
                int ganadas =elpozo [posicionJug]*3;
                System.out.println("SIETE Y MEDIO: "+ganadas);
                jug.ganarFichas(ganadas);
            }
            else{
                if (sumaCroupier==sumaJugador&&sumaCroupier<=7.5){
                    System.out.println("EMPATE");
                }
                else{
                    if (sumaJugador<= 7.5 && sumaJugador>sumaCroupier && sumaCroupier<=7.5){
                        int ganadas =elpozo [posicionJug]*2;
                        System.out.println("GANA: "+ ganadas);
                        jug.ganarFichas(ganadas);
                    }
                    else{
                        if (sumaJugador<=7.5 && sumaCroupier>7.5) {
                            int ganadas =elpozo [posicionJug]*2;
                            System.out.println("GANA: "+ ganadas);
                            jug.ganarFichas(ganadas);
                        }
                        else{
                            System.out.println("PERDIO");
                        }
                    }
                }
            }
            posicionJug++;
        }
    }

    private void limpiarCartas() {
        System.out.println(LINEA);
        System.out.println("DESCARTANDO!!");
        System.out.println(LINEA);
        
        for (JugadorCliente jug : losJugadores) {
            while(!jug.getMano().vacio()){
                elMazo.set(jug.getMano().get());
            }
        }
        while(!elCroupier.getMano().vacio()){
            elMazo.set(elCroupier.getMano().get());
        }
        elMazo.mezclar();
    }
    
    
    
}
