package jugadores;

public class Croupier extends JugadorBlackJack{

    public Croupier(String nombre) {
        super(nombre);
    }

    @Override
    public boolean sePlanta() {
        
        if (laSumaDeLasCartas()>6) {
            System.out.println("SE PLANTA");
            return true;
        }
        
       return false;
        
         
    }
    
    
}
