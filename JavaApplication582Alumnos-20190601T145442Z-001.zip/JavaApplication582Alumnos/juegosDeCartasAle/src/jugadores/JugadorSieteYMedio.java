package jugadores;

import cartas.Carta;
import mazos.MazoSieteYMedio;

public abstract class JugadorSieteYMedio extends JugadorCartas implements Plantable{

    public JugadorSieteYMedio(String nombre) {
        super(nombre);
        mano = new MazoSieteYMedio();
    }

public int cantidadCartas(){
    return mano.tamanio();
}    
public void tomaCarta(Carta c){
        mano.set(c);
    }

public int laSumaDeLasCartas(){
        int suma=0;
        
        for (int i = 0; i < mano.tamanio(); i++) {
        
            Carta c = mano.ver(i);
            if (c.getNumero()>7) {
                    suma+=0.5;
            }
            else {
               suma+=c.getNumero();
            }
        }
        return suma;
    }

}