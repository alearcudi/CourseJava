package jugadores;

public interface Plantable {
    boolean sePlanta();
}
