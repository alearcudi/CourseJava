package mazos;

import cartas.CartaEspaniola;

public class MazoSieteYMedio extends Mazo{
    
        public MazoSieteYMedio() {
        super();
    }

    @Override
    public void llenar() {
            for (int numero = 1; numero <= 10; numero++) {
                for (int palo = 1; palo <= 4; palo++) {
                    lasCartas.add(new CartaEspaniola(numero, palo));
                }
            }
    }
        
    public CartaEspaniola get(){
        return (CartaEspaniola)lasCartas.remove(0);
    }
    public CartaEspaniola get(int posicion){
        return (CartaEspaniola)lasCartas.remove(posicion);
    }
    public void set(CartaEspaniola c){
       lasCartas.add(c);
    }
    public void set(int posicion,CartaEspaniola c){
       lasCartas.add(posicion, c);
    }
}
