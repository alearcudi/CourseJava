package Main;

import juegos.BlackJack;
import juegos.SieteYMedio;
import jugadores.JugadorComputadora;
import jugadores.JugadorHumano;

public class Main {

   
    public static void main(String[] args) {

            SieteYMedio juego = new SieteYMedio();

//            BlackJack juego = new BlackJack();
           
//            juego.agregarJugador(new JugadorComputadora("Compu Uno",100));
            juego.agregarJugador(new JugadorHumano("Juan",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Dos",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Tres",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Cuatro",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Cinco",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Seis",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Siete",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Ocho",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Nueve",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Diez",100));
            
            juego.jugar();

  
    }
    
}
