package lumimaagenda;

public class Main {

    public static void main(String[] args) {
        new Agenda("CONTACTOS.TXT").inicio();
    }
    
}
