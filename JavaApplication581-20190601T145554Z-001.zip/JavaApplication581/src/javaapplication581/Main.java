package javaapplication581;

public class Main {

    private static final int NO_ENCONTRADO = -1;
    
    public static void main(String[] args) {
        
        int a;
        
        a = 3;
        
        int []b = llenarRandom(10,-10,10);
        
        mostrar("vec: ",b,',');
        int numero = enteroRandom(-10, 10);
        int posicion = buscar(b,numero);
        if (posicion == NO_ENCONTRADO) {
            System.out.println(numero + " NO ESTA!!!!");
        }
        else{
            System.out.println(numero +" ESTA EN LA POS: " + posicion);
        }
    }

    private static void mostrar(String titulo,int[] b,char separador) {
        System.out.print(titulo);
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i]);
            if (  i != (b.length-1)   ) {
                System.out.print(separador);
            }
            else{
                System.out.println("");
            }
        }
       
    }
    
    private static boolean existe(int[] dondeBuscar,int loBuscado){
        int posEncontrado = 0;
        
        for(posEncontrado=0;posEncontrado<dondeBuscar.length;posEncontrado++){
            if (dondeBuscar[posEncontrado]==loBuscado) {
                return true;
            }
        }
        return false;
    }
    private static int buscar(int[] dondeBuscar,int loBuscado){
        int posEncontrado = 0;
        
        for(posEncontrado=0;posEncontrado<dondeBuscar.length;posEncontrado++){
            if (dondeBuscar[posEncontrado]==loBuscado) {
                return posEncontrado;
            }
        }
        return NO_ENCONTRADO;
    }
    
    
    private static int enteroRandom(int desde,int hasta){
        return (int)(Math.random() * (hasta-desde+1) + desde );
    }

    private static int[] llenarRandom(int tamanioDelArreglo,
            int numeroDesde,int numeroHasta) {
        int [] sale = new int[tamanioDelArreglo]; 
        
        for (int i = 0; i < sale.length; i++) {
            sale[i] = enteroRandom(numeroDesde,numeroHasta);
        }
        
        return sale;
    }
}
