package cartas;

public class CartaEspaniola {
    
}
