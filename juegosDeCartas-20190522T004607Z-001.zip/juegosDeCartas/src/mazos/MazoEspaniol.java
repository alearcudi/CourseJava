package mazos;

public class MazoEspaniol {
    
}
