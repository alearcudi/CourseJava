package Main;

import juegos.BlackJack;
import jugadores.JugadorHumano;

public class Main {

   
    public static void main(String[] args) {


            BlackJack juego = new BlackJack();
            
//            juego.agregarJugador(new JugadorComputadora("Compu Uno",100));
            juego.agregarJugador(new JugadorHumano("Juan",100));
//            juego.agregarJugador(new JugadorComputadora("Compu Dos",200));
//            juego.agregarJugador(new JugadorComputadora("Compu Tres",159));
            
            juego.jugar();

  //      new Guerra("Juan", "Pinchame").jugar();
    }
    
}
