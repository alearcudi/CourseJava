package jugadores;

interface Apostable {
    int hacerApuesta();
}
